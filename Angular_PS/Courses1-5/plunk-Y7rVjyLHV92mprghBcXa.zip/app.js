
( function(){
  var app = angular.module("viewer", []);
  }()); 
