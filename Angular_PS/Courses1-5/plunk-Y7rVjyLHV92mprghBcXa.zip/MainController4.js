// Fathom out NG-SHOW

(function() {
  var app = angular.module("viewer");

  var MainController4 = function(
      $scope, $http, $interval, 
      $log, $location, $anchorScroll){
    
      //$location service changes address bar
      //$anchorScroll moves to an anchor
      
    
      var onUserComplete=function(response){
          $scope.user = response.data;
          $http.get($scope.user.repos_url)
            .then(onRepos, onError);
      };
    
      var onRepos = function(response){
          $scope.repos = response.data;
          //or use $scope.user.repos
          
          $location.hash("ShowMe"); // Change URL to include section marked
          $anchorScroll();
      };
    
      var onError = function (reason){
        $scope.error = reason;
      };
    
     $scope.search = function(username){
       $log.info("You searched for " + $scope.username);
        $http.get("https://api.github.com/users/" + username)
          .then(onUserComplete, onError); //Only invoke if sucessful
     }
     
     $scope.search = function(){
       $log.info("You searched for " + $scope.username);
       
       if (countdownInterval){
          $interval.cancel(countdownInterval);  //Stop Countdown
          $scope.countdown =null; //Clear screen
       }
       
        $http.get("https://api.github.com/users/" + $scope.username)
          .then(onUserComplete, onError); //Only invoke if sucessful
          
     }
    
    var decrementCountdown = function(){
      $scope.countdown -=1;
      if ($scope.countdown <1){
        $scope.search($scope.username);
      }
    };
    
    var countdownInterval = null;
    
    var startCountdown = function(){
      //Interval is a function
      countdownInterval = $interval(decrementCountdown, 1000, $scope.countdown); //3rd arg is number of intervals
    }
    
      $http.get("https://api.github.com/users/robconery")
        .then(onUserComplete, onError); //Only invoke if sucessful
         
      $scope.username="angular"; // STVHunter2017
      $scope.message = "Github Viewer";
      $scope.repoSortOrder = "-stargazers_count";
      $scope.repoUserOrder ="-stargazers_count";
      $scope.includeOption = "include.html" ;
      $scope.countdown = 5;
      startCountdown();
  };

  //Once using the "$http" all services must be supplied
  //app.controller("MainController4", ["$scope", "$http", "$interval", MainController4]);
  
  app.controller("MainController4", MainController4);

}());