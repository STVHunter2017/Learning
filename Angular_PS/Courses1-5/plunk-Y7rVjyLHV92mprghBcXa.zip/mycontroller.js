// Code goes here

(function() {
    var app = angular.module("viewer");

    var MyController = function($scope) {
        $scope.message = "Hello";
        $scope.mouse=2;
        
        $scope.name ={}
        $scope.name.firstname ="Steve";
        $scope.name.lastname ="Hyles";
    };
    
    app.controller("MyController", ["$scope", MyController]);

  }()); 