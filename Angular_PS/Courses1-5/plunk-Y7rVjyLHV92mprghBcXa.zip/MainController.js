(function() {
  var app = angular.module("viewer");

  var person = {
    firstName: "Scott",
    lastName: "Allen",
    imageSrc: "ahttp://odetocode.com/Images/scott_allen_2.jpg"
  };

  var MainController = function($scope, $http){
     $scope.message = "Hello";
     $scope.person = person;
     
     //All comms is async
     //$scope.user = $http.get("/users/1783");
     var promise = $http.get("/users/1783");
     
     promise.then(function(response){
       $scope.user = response.data;
     });
     
  };

  app.controller("MainController", ["$scope", "$http", MainController]);

}());