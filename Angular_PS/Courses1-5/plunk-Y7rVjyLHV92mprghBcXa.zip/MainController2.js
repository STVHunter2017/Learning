(function() {
  var app = angular.module("viewer");

  var MainController2 = function($scope, $http){
    
      var onUserComplete=function(response){
          $scope.user = response.data;
      };
    
      var onError = function (reason){
        $scope.error = reason;
      };
    
     $http.get("https://api.github.com/users/robconery")
        .then(onUserComplete, onError); //Only invoke if sucessful
         
    
     $scope.message = "Hello";
     
  };

  app.controller("MainController2", ["$scope", "$http", MainController2]);

}());