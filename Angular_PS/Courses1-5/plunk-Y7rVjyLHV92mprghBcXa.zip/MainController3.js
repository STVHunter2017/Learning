// Fathom out NG-SHOW

(function() {
  var app = angular.module("viewer");

  var MainController3 = function($scope, $http){
    
      var onUserComplete=function(response){
          $scope.user = response.data;
          $http.get($scope.user.repos_url)
            .then(onRepos, onError);
      };
    
      var onRepos = function(response){
          $scope.repos = response.data;
          //or use $scope.user.repos
      };
    
      var onError = function (reason){
        $scope.error = reason;
      };
    
     $scope.search = function(username){
        $http.get("https://api.github.com/users/" + username)
          .then(onUserComplete, onError); //Only invoke if sucessful
     }
     
     $scope.search = function(){
        $http.get("https://api.github.com/users/" + $scope.username)
          .then(onUserComplete, onError); //Only invoke if sucessful
     }
     
    
      $http.get("https://api.github.com/users/robconery")
        .then(onUserComplete, onError); //Only invoke if sucessful
         
      var Dblclick = function (){
        alert("You double clicked this");
      }
    
      $scope.username=""; // STVHunter2017
      $scope.message = "Github Viewer";
      $scope.repoSortOrder = "-stargazers_count";
      $scope.repoUserOrder ="-stargazers_count";
      $scope.includeOption = "include.html" ;
      $scope.dblclick = Dblclick;
  };

  app.controller("MainController3", ["$scope", "$http", MainController3]);

}());